import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
//import { User } from '../_models/users';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {

    constructor(private http: HttpClient) {       
    }
    login(mobile:any) {
        return this.http.post<any>(`http://65.1.176.15:5050/apis/customerLogin`, {"orgId":"bata", "phone":mobile})
            .pipe(map(user => {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                return user;
            }));
    }

    
}