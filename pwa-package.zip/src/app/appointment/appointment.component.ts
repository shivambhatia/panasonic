import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
  count= '1';
  
  data : any;
  private token : string;
  appointment: any;
  constructor(private http: HttpClient) {    
    this.token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25OYW1lIjoiYmF0YSIsImlhdCI6MTYyODE2MzgzMCwiZXhwIjoxNjI4ODU1MDMwfQ.0MX9h8hrCEQmeH49TZiU9Akn7bHXQ7bnqZsrcXfJEIk'       
  }

  ngOnInit() {
    const headers = { 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25OYW1lIjoiYmF0YSIsImlhdCI6MTYyODE2MzgzMCwiZXhwIjoxNjI4ODU1MDMwfQ.0MX9h8hrCEQmeH49TZiU9Akn7bHXQ7bnqZsrcXfJEIk', 'My-Custom-Header': '' }
    
    let resp=this.http.post('http://65.1.176.15:5050/apis/getCustomerAppointments',{"id":1}, { headers: headers});
    //resp.subscribe((result)=>this.users=result);
    
    resp.subscribe((result)=>{    
      this.data=result
      this.appointment = this.data.result
      console.warn(this.data);      
      
    })
  }
  

}
