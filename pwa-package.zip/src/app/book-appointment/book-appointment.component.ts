import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
declare var $: any;

@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {

  data : any;
  services: any;
  private token : string;


  dataService = true;
  dataBranch = false;
  dataDateTime = false;
  dataContact = false;
  dataReview = false;
  dataRequest = false;
  toggle(){
    this.dataService = !this.dataService,
    this.dataBranch = !this.dataBranch
    this.dataDateTime
    this.dataContact = !this.dataContact
    this.dataReview = !this.dataReview
    this.dataRequest = !this.dataRequest
  }

  constructor(private http: HttpClient) {    
    this.token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25OYW1lIjoiYmF0YSIsImlhdCI6MTYyODE2MzgzMCwiZXhwIjoxNjI4ODU1MDMwfQ.0MX9h8hrCEQmeH49TZiU9Akn7bHXQ7bnqZsrcXfJEIk'       
  }

  ngOnInit() {
    const headers = { 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6YXRpb25OYW1lIjoiYmF0YSIsImlhdCI6MTYyODE2MzgzMCwiZXhwIjoxNjI4ODU1MDMwfQ.0MX9h8hrCEQmeH49TZiU9Akn7bHXQ7bnqZsrcXfJEIk', 'My-Custom-Header': '' }
    
    let resp=this.http.post('http://65.1.176.15:5050/apis/getAllServices',{"id":1}, { headers: headers});
    //resp.subscribe((result)=>this.users=result);
    
    resp.subscribe((result)=>{    
      this.data=result
      this.services = this.data.result
      console.warn(this.data);      
      
    })
    $(document).ready(function() {
      $('.datepicker').datepicker();	
    });
  }

}
