import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {

    $(document).ready(function() {	
      setTimeout(function(){
        $('body').addClass('loaded');
        $('h1').css('color','#222222')
      }, 3000);

    });
  }

}
