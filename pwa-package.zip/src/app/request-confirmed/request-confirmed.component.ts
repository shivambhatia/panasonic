import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-confirmed',
  templateUrl: './request-confirmed.component.html',
  styleUrls: ['./request-confirmed.component.css']
})
export class RequestConfirmedComponent implements OnInit {
  title = 'Request Confirmed';
  constructor() { }

  ngOnInit(): void {
  }

}
