// JavaScript Document

$(document).ready(function(){		
	$('.datepicker').datepicker();	
	

});