import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { formatDate } from "@angular/common";
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;
import { FormGroup, FormControl ,Validators} from '@angular/forms';
@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {

  data : any;
  temp :any;
  services: any;
  private token : string;
  selectedServices:string [];  
  allBranchesServiceWise:any[];
  dataService = true;
  dataBranch = false;
  dataDateTime = false;
  dataContact = false;
  dataReview = false;
  dataRequest = false;
  startRegistartionDate:any;
  allDateBranchWiseData : any[];
  datetimeArray: string[];
  time:string;
  name:string;
  phone:string;
  email:string;
  note:string;
  tnc:string;
  dateData:string ;
  
  public userDataProfile:any =[];

  

togglePrevious(pageType:string){
  if (pageType=='branch'){
    this.dataService=true;
    this.dataBranch=false;
  }
  if(pageType=='datetime'){
    this.dataBranch=true;
    this.dataDateTime=false;
  }
  if(pageType=='requirement'){
    this.dataDateTime=true;
    this.dataContact=false;
  }


}
  toggle(pageType:string){
  
    if(pageType=='service'){
    if(this.selectedServices.length==0){

      //
    }
    else{
      
      this.getBranchOnSelectedServices();

    this.dataService = false;
    this.dataBranch = true;
    }
  }
  if(pageType=='datetime'){
    

      if(parent && this.time){
          this.dateData=JSON.stringify(parent).split('T')[0];

          this.dateData=this.dateData.replaceAll('"',"");
          var temp=this.dateData.split('-');
          this.dateData=temp[2]+"-"+temp[1]+'-'+temp[0]

          

        this.dataDateTime=false;
        this.dataContact=true;
        if(this.userDataProfile){
        this.profileForm.controls["profilename"].setValue(this.userDataProfile.name);
       this.profileForm.controls["email"].setValue(this.userDataProfile.email);
        this.profileForm.controls["phone"].setValue(this.userDataProfile.phone);
        this.profileForm.controls['profilename'].disable();
        this.profileForm.controls['email'].disable();
        this.profileForm.controls['phone'].disable();
        this.email=this.userDataProfile.email;
        this.name=this.userDataProfile.name;
        this.phone=this.userDataProfile.phone;
         
      }
        
         
      }
      else{

        console.log("Select toh kr le");
      }
  }

  if(pageType=='branch'){
    // check branch selected;

    if(this.allBranchesServiceWise.length==0){
      

    }
    else{
      //debugger;
      //this.getNoOfDaysOnSelectedBranch();
      this.getDateTimeOnSelectedBranch();
      this.dataBranch=false;
      this.dataDateTime=true;
      //var myDate = new Date(new Date().getTime()+(5*24*60*60*1000));

      $(document).ready(function() {
        var currentdate = new Date(); 
        var someDate = new Date();
var numberOfDaysToAdd = 15;
someDate.setDate(someDate.getDate() + numberOfDaysToAdd); 
        console.log("Current Date",currentdate.getFullYear()+currentdate.getMonth()+currentdate.getDay());

      $('.datepicker').datepicker({
        format: "yy-mm-dd",
    startDate: new Date(currentdate.getFullYear() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getDate()),
    endDate: new Date(someDate.getFullYear() + "/"
                + (someDate.getMonth()+1)  + "/" 
                + someDate.getDate())
      }).on('changeDate', function(e:any) {  
        parent=e.date
        //this.getDateTimeOnSelectedBranch();    
    

      });   
      
    });


      
    }
  }
  if(pageType=='requirement'){
    this.dataContact=false;
    this.dataReview=true;
  }



    // this.dataDateTime
    // this.dataContact = !this.dataContact
    // this.dataReview = !this.dataReview
    // this.dataRequest = !this.dataRequest
  }

   profileForm = new FormGroup({
    profilename: new FormControl({value:''}, Validators.required),
    email: new FormControl({value:'',disabled:true}, Validators.required),
    phone :new FormControl({value:'',disabled:true}, Validators.required),
    tnc :new FormControl('', Validators.required),
    note:new FormControl('', Validators.required)
  });


   getNoOfDaysOnSelectedBranch(){
        const headers = { 'Authorization': 'Bearer '+this.token, 'My-Custom-Header': '' }
    var request={"service":[this.selectedServices[0]],"branch":[this.allBranchesServiceWise[0].id]} 
    console.log("Step 2",request)  
    let resp=this.http.post('http://65.1.176.15:5050/apis/getBookedSlot',request, { headers: headers});
   
    resp.subscribe((result)=>{    
     console.log("Max no of days from today",result);
      
    })

   }

   createAppointment(){
        const headers = { 'Authorization': 'Bearer '+this.token }
    var request={"appointment_date":this.dateData,"appointment_time":this.time,"email":this.email,"name":this.name,"note":this.note,"tnc":this.tnc,"mobile":this.phone,"services":this.selectedServices,"mode":"web","branch":[[this.allBranchesServiceWise[0].id]]};
    console.log("Check Headers",request); 
    let resp=this.http.post('http://65.1.176.15:5050/apis/create_appointment',request, { headers: headers});
    
    resp.subscribe((result)=>{
      debugger;


      this.router.navigate(['/appointment']);

    
    })


   }

onContactSubmit(){
  console.log("Check all values",this.profileForm.value);
   this.name=this.userDataProfile?this.userDataProfile.name:this.profileForm.value.profilename;
  this.phone=this.userDataProfile?this.userDataProfile.phone:this.profileForm.value.phone;
   this.email=this.userDataProfile?this.userDataProfile.email:this.profileForm.value.email;
   this.note=this.profileForm.value.note;
   this.tnc=this.profileForm.value.tnc;
     
}

  constructor(private http: HttpClient,private router: Router) { 
    
  let users = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if(users.success){
          debugger;
          this.userDataProfile=users.result;



            this.token = users.token;       
    this.selectedServices=[];
    this.allBranchesServiceWise=[];
    this.allDateBranchWiseData=[];
             
        }   
      else{
        this.router.navigate(['/login']);
      }
  }

  createDateTimePair(open_time:string,close_time:string){
    
    var x = 30; //minutes interval
var times = []; // time array
var tt = parseInt(open_time.split(':')[0])*60+parseInt(open_time.split(':')[1]); // start time
var ap = ['AM', 'PM']; // AM-PM


//loop to increment the time and push results in array
for (var i=0;tt<=(parseInt(close_time.split(':')[0])*60+parseInt(close_time.split(':')[1])); i++) {
  var hh = Math.floor(tt/60); // getting hours of day in 0-24 format
  var mm = (tt%60); // getting minutes of the hour in 0-55 format
  times[i] = ("0" + (hh % 12)).slice(-2) + ':' + ("0" + mm).slice(-2) + ap[Math.floor(hh/12)]; // pushing data in array in [00:00 - 12:00 AM/PM format]
  tt = tt + x;
}
var datetimeArray=[];
for(i=0;i<times.length-1;i++){
  datetimeArray.push(times[i]+'-'+times[i+1]);
  

}
this.datetimeArray=datetimeArray;




  }
  onItemChangeTime(value:any){
    this.time=this.datetimeArray[value];

  }

  

  getDateTimeOnSelectedBranch(){
       const headers = { 'Authorization': 'Bearer '+this.token, 'My-Custom-Header': '' }
    
    let resp=this.http.post('http://65.1.176.15:5050/apis/getServiceData',{"service":this.selectedServices[0],"branch":this.allBranchesServiceWise[0].id,"appointment_date":"12-08-2021"}, { headers: headers});
   
    resp.subscribe((result)=>{    
      this.temp=result
      this.allDateBranchWiseData = this.temp.result;
      
      //console.log(this.temp.result.open_time);
      this.createDateTimePair(this.temp.result.open_time,this.temp.result.close_time);
      
    })
  }

  getBranchOnSelectedServices(){

    const headers = { 'Authorization': 'Bearer '+this.token, 'My-Custom-Header': '' }
    
    let resp=this.http.post('http://65.1.176.15:5050/apis/getServiceWiseBranch',{"service_name":this.selectedServices}, { headers: headers});
   
    resp.subscribe((result)=>{    
      this.temp=result
      this.allBranchesServiceWise = this.temp.result
      //
      console.log("All branch data",this.allBranchesServiceWise);
      
    })



  }

  ngOnInit() {
    const headers = { 'Authorization': 'Bearer '+this.token, 'My-Custom-Header': '' }
    console.log("Step 1",headers);
    var parent=this;
    let resp=this.http.post('http://65.1.176.15:5050/apis/getAllServices',{}, { headers: headers});
    //resp.subscribe((result)=>this.users=result);
    this.selectedServices=new Array<string>();
    resp.subscribe((result)=>{    
      this.data=result
      this.services = this.data.result
      console.log("Step 1",this.services);
           
      
    })
    $(document).ready(function() {
      $('.datepicker').datepicker({
        format: "yy-mm-dd",
    startDate: new Date('2019-12-5'),
    endDate: new Date('2020-7-12')    
      }).on('changeDate', function(e:any) {  
        console.log("You changed me",e.date); 
    });   
      
    });
  }
  getSelectedServiceId(e:any,id:string){


    if(e.target.checked){
      this.selectedServices=[];
      //console.log("Checked Id",id);
      this.selectedServices.push(id);
    }

    else{
      this.selectedServices=this.selectedServices.filter(m=>m!=id);
    }
    //console.log("Checking all the data",this.selectedServices);
  }
  datetimeChangeCheck(value:any){
    console.log("Check Value",value);

  } 

}
