import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-review',
  templateUrl: './request-review.component.html',
  styleUrls: ['./request-review.component.css']
})
export class RequestReviewComponent implements OnInit {
  title = 'Review Request';
  constructor() { }

  ngOnInit(): void {
  }

}
